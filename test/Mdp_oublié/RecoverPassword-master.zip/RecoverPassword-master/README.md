# RecoverPassword

Code source de la vidéo pour créer son système de "mot de passe oublié".
Des mises à jours ou modifications de code viendront peut-être par la suite.

Attention dans la vidéo je met une taille varchar de 64 pour token et token_user, mettez à 130 ! sinon il y aura une erreur ! 

N'hésitez pas à fork et star ;)

# Vidéo
https://www.youtube.com/watch?v=T-felqUpR_0


# Licence
Open source

